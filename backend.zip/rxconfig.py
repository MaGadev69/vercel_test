import reflex as rx

config = rx.Config(app_name="integracion_minimal_web_page")