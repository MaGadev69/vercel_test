import reflex as rx

config = rx.Config(
    app_name="integracion_minimal_web_page",
    bun={"disable_export_sitemap": True},
    )