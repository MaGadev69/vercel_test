# config/api.py

# URLs del backend
BACKEND_URL = "https://appstockbackend-production.up.railway.app"

# Endpoints
PRODUCTOS_ACTIVOS_CANTIDAD = f"{BACKEND_URL}/productos/productos/activos/cantidad"
